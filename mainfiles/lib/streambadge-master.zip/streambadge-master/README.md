#Streambadge

##ABOUT:

Streambadge helps you gain viewership by displaying your live stream status. Select your video stream service, add your username, and grab the code! Paste the code to your website, blog, forum signature, or where ever you like!

Streambadge accesses your live stream information through various service API requests. Current services include; Twitch.tv, Justin.tv, UStream.tv, GoodGame.ru, hitbox.tv, and Livestream.com.

##LIVE:

[Try it out here](http://streambadge.com)
