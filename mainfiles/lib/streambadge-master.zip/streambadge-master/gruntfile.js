// Generated on 2013-11-02 using generator-webapp 0.4.3
'use strict';

// # Globbing
// for performance reasons we're only matching one level down:
// 'test/spec/{,*/}*.js'
// use this if you want to recursively match all subfolders:
// 'test/spec/**/*.js'

module.exports = function (grunt) {
    // show elapsed time at the end
    require('time-grunt')(grunt);
    // load all grunt tasks
    require('load-grunt-tasks')(grunt);

    grunt.initConfig({
        // configurable paths
        yeoman: {
            app: 'app',
            dist: 'dist'
        },
        watch: {
            compass: {
                files: ['<%= yeoman.app %>/styles/{,*/}*.{scss,sass}'],
                tasks: ['compass:server', 'autoprefixer']
            },
            styles: {
                files: ['<%= yeoman.app %>/styles/{,*/}*.css'],
                tasks: ['copy:styles', 'autoprefixer']
            },
            livereload: {
                options: {
                    livereload: '<%= connect.options.livereload %>'
                },
                files: [
                    '<%= yeoman.app %>/*.html',
                    '.tmp/styles/{,*/}*.css',
                    '{.tmp,<%= yeoman.app %>}/scripts/{,*/}*.js',
                    '<%= yeoman.app %>/images/{,*/}*.{png,jpg,jpeg,gif,webp,svg}'
                ]
            }
        },
        connect: {
            options: {
                port: 9000,
                livereload: 35730,
                // change this to '0.0.0.0' to access the server from outside
                hostname: 'localhost'
            },
            livereload: {
                options: {
                    open: true,
                    base: [
                        '.tmp',
                        '<%= yeoman.app %>'
                    ]
                }
            },
            test: {
            //    options: {
            //        base: [
            //            '.tmp',
            //            'test',
            //            '<%= yeoman.app %>'
            //        ]
            //    }
            },
            dist: {
                options: {
                    open: true,
                    base: '<%= yeoman.dist %>'
                }
            }
        },
        clean: {
            dist: {
                files: [{
                    dot: true,
                    src: [
                        '.tmp',
                        '<%= yeoman.dist %>/*',
                        '!<%= yeoman.dist %>/.git*'
                    ]
                }]
            },
            server: '.tmp'
        },
        jshint: {
            options: {
                jshintrc: '.jshintrc'
            },
            all: [
                'Gruntfile.js',
                '<%= yeoman.app %>/scripts/{,*/}*.js',
                '!<%= yeoman.app %>/scripts/vendor/*',
                'test/spec/{,*/}*.js'
            ]
        },
        mocha: {
        //    all: {
        //        options: {
        //            run: true,
        //            urls: ['http://<%= connect.test.options.hostname %>:<%= connect.test.options.port %>/index.html']
        //        }
        //    }
        },
        compass: {
            options: {
                sassDir: '<%= yeoman.app %>/styles',
                cssDir: '.tmp/styles',
                generatedImagesDir: '.tmp/images/generated',
                imagesDir: '<%= yeoman.app %>/images',
                javascriptsDir: '<%= yeoman.app %>/scripts',
                fontsDir: '<%= yeoman.app %>/styles/fonts',
                importPath: '<%= yeoman.app %>/bower_components',
                httpImagesPath: '/images',
                httpGeneratedImagesPath: '/images/generated',
                httpFontsPath: '/styles/fonts',
                relativeAssets: false,
                assetCacheBuster: false
            },
            dist: {
                options: {
                    generatedImagesDir: '<%= yeoman.dist %>/images/generated'
                }
            },
            server: {
                options: {
                    debugInfo: true
                }
            }
        },
        autoprefixer: {
            options: {
                browsers: ['last 1 version']
            },
            dist: {
                files: [{
                    expand: true,
                    cwd: '.tmp/styles/',
                    src: '{,*/}*.css',
                    dest: '.tmp/styles/'
                }]
            }
        },
        // not used since Uglify task does concat,
        // but still available if needed
        /*concat: {
            dist: {}
        },*/
        rev: {
            dist: {
                files: {
                    src: [
                        '<%= yeoman.dist %>/scripts/{,*/}*.js',
                        '<%= yeoman.dist %>/styles/{,*/}*.css',
                        //'<%= yeoman.dist %>/images/{,*/}*.{png,jpg,jpeg,gif,webp}',
                        //'<%= yeoman.dist %>/styles/fonts/{,*/}*.*'
                    ]
                }
            }
        },
        useminPrepare: {
            options: {
                dest: '<%= yeoman.dist %>'
            },
            html: [
                '<%= yeoman.app %>/index.html',
                '<%= yeoman.app %>/iframe-badge/index.html'
            ]
        },
        usemin: {
            options: {
                dirs: ['<%= yeoman.dist %>']
            },
            html: ['<%= yeoman.dist %>/{,*/}*.html'],
            css: ['<%= yeoman.dist %>/styles/{,*/}*.css']
        },
        imagemin: {
            dist: {
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.app %>/images',
                    src: '{,*/}*.{png,jpg,jpeg}',
                    dest: '<%= yeoman.dist %>/images'
                }]
            }
        },
        svgmin: {
        //    dist: {
        //        files: [{
        //            expand: true,
        //            cwd: '<%= yeoman.app %>/images',
        //            src: '{,*/}*.svg',
        //            dest: '<%= yeoman.dist %>/images'
        //        }]
        //    }
        },
        cssmin: {
            // This task is pre-configured if you do not wish to use Usemin
            // blocks for your CSS. By default, the Usemin block from your
            // `index.html` will take care of minification, e.g.
            //
            //     <!-- build:css({.tmp,app}) styles/main.css -->
            //
            // dist: {
            //     files: {
            //         '<%= yeoman.dist %>/styles/main.css': [
            //             '.tmp/styles/{,*/}*.css',
            //             '<%= yeoman.app %>/styles/{,*/}*.css'
            //         ]
            //     }
            // }
        },
        htmlmin: {
            dist: {
                options: {
                    /*removeCommentsFromCDATA: true,
                    // https://github.com/yeoman/grunt-usemin/issues/44
                    //collapseWhitespace: true,
                    collapseBooleanAttributes: true,
                    removeAttributeQuotes: true,
                    removeRedundantAttributes: true,
                    useShortDoctype: true,
                    removeEmptyAttributes: true,
                    removeOptionalTags: true*/
                },
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.app %>',
                    src: '*.html',
                    dest: '<%= yeoman.dist %>'
                }]
            }
        },
        // Put files not handled in other tasks here
        copy: {
            dist: {
                files: [
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>',
                        dest: '<%= yeoman.dist %>',
                        src: [
                            '*.{ico,png,txt}',
                            '.htaccess',
                            'images/{,*/}*.{webp,gif}',
                            'styles/fonts/{,*/}*.*'
                        ]
                    },
                    // Legacy
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/iframe-badge',
                        dest: '<%= yeoman.dist %>/twitch',
                        src: 'index.html'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/iframe-badge',
                        dest: '<%= yeoman.dist %>/justin',
                        src: 'index.html'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/iframe-badge',
                        dest: '<%= yeoman.dist %>/ustream',
                        src: 'index.html'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/iframe-badge',
                        dest: '<%= yeoman.dist %>/goodgame',
                        src: 'index.html'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/iframe-badge',
                        dest: '<%= yeoman.dist %>/hitbox',
                        src: 'index.html'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/iframe-badge',
                        dest: '<%= yeoman.dist %>/livestream',
                        src: 'index.html'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/image-badge',
                        dest: '<%= yeoman.dist %>/twitch',
                        src: 'index.php'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/image-badge',
                        dest: '<%= yeoman.dist %>/justin',
                        src: 'index.php'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/image-badge',
                        dest: '<%= yeoman.dist %>/ustream',
                        src: 'index.php'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/image-badge',
                        dest: '<%= yeoman.dist %>/goodgame',
                        src: 'index.php'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/image-badge',
                        dest: '<%= yeoman.dist %>/hitbox',
                        src: 'index.php'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/image-badge',
                        dest: '<%= yeoman.dist %>/livestream',
                        src: 'index.php'
                    },
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>/image-badge',
                        dest: '<%= yeoman.dist %>',
                        src: 'php-ga/**/{,*/}*.php'
                    }
                ]
            },
            styles: {
                expand: true,
                dot: true,
                cwd: '<%= yeoman.app %>/styles',
                dest: '.tmp/styles/',
                src: '{,*/}*.css'
            }
        },
        rename: {
            dist: {
                files: [
                    {
                        src: '<%= yeoman.dist %>/twitch/index.php',
                        dest: '<%= yeoman.dist %>/twitch/badge.php'
                    },
                    {
                        src: '<%= yeoman.dist %>/justin/index.php',
                        dest: '<%= yeoman.dist %>/justin/badge.php'
                    },
                    {
                        src: '<%= yeoman.dist %>/ustream/index.php',
                        dest: '<%= yeoman.dist %>/ustream/badge.php'
                    },
                    {
                        src: '<%= yeoman.dist %>/goodgame/index.php',
                        dest: '<%= yeoman.dist %>/goodgame/badge.php'
                    },
                    {
                        src: '<%= yeoman.dist %>/hitbox/index.php',
                        dest: '<%= yeoman.dist %>/hitbox/badge.php'
                    },
                    {
                        src: '<%= yeoman.dist %>/livestream/index.php',
                        dest: '<%= yeoman.dist %>/livestream/badge.php'
                    }
                ]
            }
        },
        concurrent: {
            server: [
                'compass',
                'copy:styles'
            ],
            test: [
                'copy:styles'
            ],
            dist: [
                'compass',
                'copy:styles',
                'imagemin',
                //'svgmin',
                'htmlmin'
            ]
        },
        bower: {
        //    all: {
        //       rjsConfig: '<%= yeoman.app %>/scripts/main.js'
        //    }
        }
    });

    grunt.registerTask('server', function (target) {
        if (target === 'dist') {
            return grunt.task.run(['build', 'connect:dist:keepalive']);
        }

        grunt.task.run([
            'clean:server',
            'concurrent:server',
            'autoprefixer',
            'connect:livereload',
            'watch'
        ]);
    });

    grunt.registerTask('test', [
        'clean:server',
        'concurrent:test',
        'autoprefixer',
        'connect:test',
        //'mocha'
    ]);

    grunt.registerTask('build', [
        'clean:dist',
        'useminPrepare',
        'concurrent:dist',
        'autoprefixer',
        'concat',
        'cssmin',
        'uglify',
        'copy:dist',
        'rename',
        'rev',
        'usemin'
    ]);

    grunt.registerTask('default', [
        'jshint',
        //'test',
        'build'
    ]);
};
